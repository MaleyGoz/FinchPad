mod app_state;
mod editor;
mod encoding;
mod file_io;
mod line_ending;

use app_state::{AppState, ExternalChange, SaveOutcome};
use slint::{ModelRc, SharedString, VecModel};
use std::{cell::RefCell, rc::Rc};
use windows::{
    Win32::Foundation::RECT,
    Win32::Graphics::Gdi::{
        CreateFontIndirectW, DeleteObject, DrawTextExW, GetDC, ReleaseDC, SelectObject,
        DT_CALCRECT, DT_NOPREFIX, DT_WORDBREAK, FONT_CHARSET, FONT_CLIP_PRECISION,
        FONT_OUTPUT_PRECISION, FONT_QUALITY, HDC, HFONT, HGDIOBJ, LOGFONTW,
    },
};

slint::include_modules!();

fn main() -> Result<(), Box<dyn std::error::Error>> {
    let pending_conflict = Rc::new(RefCell::new(None::<usize>));
    let pending_light_conflict = Rc::new(RefCell::new(None::<usize>));
    let window = MainWindow::new()?;
    let tooltip_window = Rc::new(TooltipWindow::new()?);
    let _ = tooltip_window.hide();

    let state = Rc::new(RefCell::new(AppState::new()));
    let pending_close = Rc::new(RefCell::new(None::<usize>));
    let pending_close_queue = Rc::new(RefCell::new(Vec::<usize>::new()));
    let find_position = Rc::new(RefCell::new(0usize));

    // 编辑器内容变化
    {
        let state_clone = state.clone();
        let window_weak = window.as_weak();

        window.on_text_changed(move |new_text| {
            {
                let mut state = state_clone.borrow_mut();
                let tab = state.active_tab_mut();

                tab.buffer = editor::TextBuffer::from_str(&new_text);
                tab.mark_dirty();

                let (lines, chars) = editor::count_text(&new_text);
                tab.line_count = lines;
                tab.char_count = chars;
            }

            if let Some(window) = window_weak.upgrade() {
                sync_ui(&window, &state_clone);
            }
        });
    }

    // 切换标签
    {
        let state_clone = state.clone();
        let window_weak = window.as_weak();
        let pending_light_conflict_clone = pending_light_conflict.clone();

        window.on_tab_clicked(move |index| {
            if index < 0 {
                return;
            }
            let idx = index as usize;

            let mut show_light = false;

            {
                let mut state = state_clone.borrow_mut();
                state.switch_to(idx);

                let is_dirty = state.active_tab().is_dirty;
                let modified =
                    matches!(state.external_file_state(idx), Ok(ExternalChange::Modified));

                if modified {
                    if is_dirty {
                        show_light = true;
                    } else {
                        // 干净标签：静默重载
                        let _ = state.reload_tab_from_disk(idx);
                    }
                }
            }

            let Some(window) = window_weak.upgrade() else {
                return;
            };

            sync_ui(&window, &state_clone);

            if show_light {
                *pending_light_conflict_clone.borrow_mut() = Some(idx);
                let (title, message) = light_conflict_text_for(&state_clone, idx);
                window.set_light_conflict_title(title.into());
                window.set_light_conflict_message(message.into());
                window.set_light_conflict_visible(true);
            }
        });
    }

    // 拖拽标签重新排序
    {
        let state_clone = state.clone();
        let window_weak = window.as_weak();
        // 保存"正在被拖拽的标签索引"，松开鼠标后 consume 掉
        let drag_from = Rc::new(RefCell::new(None::<usize>));

        // 按下左键：记录起始索引
        window.on_tab_drag_started({
            let drag_from = drag_from.clone();
            move |index| {
                if index < 0 {
                    return;
                }
                *drag_from.borrow_mut() = Some(index as usize);
            }
        });

        // 松开左键：目标索引与起始索引不同时执行重排，并刷新 UI
        window.on_tab_drag_ended({
            let drag_from = drag_from.clone();
            let state_clone = state_clone.clone();
            let window_weak = window_weak.clone();
            move |to_index| {
                // 取走起始索引；没经过 started 就直接 ended 的异常情况直接忽略
                let Some(from) = drag_from.borrow_mut().take() else {
                    return;
                };

                if to_index < 0 {
                    return;
                }

                let to = to_index as usize;

                // 位置没变（原地点击/短距拖动被 Slint 判为未移动）：不做任何事
                if from == to {
                    return;
                }

                {
                    let mut state = state_clone.borrow_mut();
                    state.reorder_tabs(from, to);
                }

                if let Some(window) = window_weak.upgrade() {
                    sync_ui(&window, &state_clone);
                }
            }
        });
    }

    // 新建标签
    {
        let state_clone = state.clone();
        let window_weak = window.as_weak();

        window.on_new_tab_clicked(move || {
            state_clone.borrow_mut().new_tab();

            if let Some(window) = window_weak.upgrade() {
                sync_ui(&window, &state_clone);
            }
        });
    }

    // 打开多个文件
    {
        let state_clone = state.clone();
        let window_weak = window.as_weak();

        window.on_open_file_requested(move || {
            let paths = file_io::pick_open_paths();

            if paths.is_empty() {
                return;
            }

            let mut opened = false;

            {
                let mut state = state_clone.borrow_mut();

                for path in paths {
                    match file_io::read_file(&path) {
                        Ok((content, encoding, line_ending, mtime)) => {
                            state.open_file(path, &content, encoding, line_ending, mtime);
                            opened = true;
                        }
                        Err(error) => {
                            eprintln!("打开文件失败：{error}");
                        }
                    }
                }
            }

            if opened {
                if let Some(window) = window_weak.upgrade() {
                    sync_ui(&window, &state_clone);
                }
            }
        });
    }

    // 保存
    {
        let state_clone = state.clone();
        let window_weak = window.as_weak();
        let pending_conflict_clone = pending_conflict.clone();

        window.on_save_requested(move || {
            let idx = state_clone.borrow().active_index();
            let needs_dialog = state_clone.borrow().save_tab_needs_dialog(idx);

            // 从未保存过：走"另存为"对话框
            if needs_dialog {
                let default_name = {
                    let state = state_clone.borrow();
                    state.save_default_name(idx)
                };

                let Some(path) = file_io::pick_save_path(&default_name) else {
                    return;
                };

                let result = {
                    let mut state = state_clone.borrow_mut();
                    state.save_active_as(path)
                };

                match result {
                    Ok(()) => {
                        if let Some(window) = window_weak.upgrade() {
                            sync_ui(&window, &state_clone);
                        }
                    }
                    Err(error) => eprintln!("保存失败：{error}"),
                }
                return;
            }

            // 常规保存
            let result = {
                let mut state = state_clone.borrow_mut();
                state.save_tab_to_disk(idx)
            };

            match result {
                Ok(SaveOutcome::Saved) => {
                    if let Some(window) = window_weak.upgrade() {
                        sync_ui(&window, &state_clone);
                    }
                }
                Ok(SaveOutcome::Conflict(change)) => {
                    *pending_conflict_clone.borrow_mut() = Some(idx);
                    if let Some(window) = window_weak.upgrade() {
                        let (title, message) = conflict_text_for(&state_clone, idx, change);
                        window.set_conflict_title(title.into());
                        window.set_conflict_message(message.into());
                        window.set_conflict_visible(true);
                    }
                }
                Err(error) => eprintln!("保存失败：{error}"),
            }
        });
    }

    // 另存为
    {
        let state_clone = state.clone();
        let window_weak = window.as_weak();

        window.on_save_as_requested(move || {
            let default_name = {
                let state = state_clone.borrow();
                state.save_default_name(state.active_index())
            };

            let Some(path) = file_io::pick_save_path(&default_name) else {
                return;
            };

            let result = {
                let mut state = state_clone.borrow_mut();
                state.save_active_as(path)
            };

            match result {
                Ok(()) => {
                    if let Some(window) = window_weak.upgrade() {
                        sync_ui(&window, &state_clone);
                    }
                }
                Err(error) => {
                    eprintln!("另存为失败：{error}");
                }
            }
        });
    }

    // 普通关闭标签
    {
        let state_clone = state.clone();
        let pending_close_clone = pending_close.clone();
        let close_queue_clone = pending_close_queue.clone();
        let window_weak = window.as_weak();

        window.on_tab_close_requested(move |index| {
            if index < 0 {
                return;
            }

            let Some(window) = window_weak.upgrade() else {
                return;
            };

            let index = index as usize;

            if index >= state_clone.borrow().tab_count() {
                return;
            }

            start_close_request(
                &window,
                &state_clone,
                &pending_close_clone,
                &close_queue_clone,
                vec![index],
            );
        });
    }

    // 鼠标中键关闭标签
    {
        let state_clone = state.clone();
        let pending_close_clone = pending_close.clone();
        let close_queue_clone = pending_close_queue.clone();
        let window_weak = window.as_weak();

        window.on_tab_middle_close_requested(move |index| {
            if index < 0 {
                return;
            }

            let Some(window) = window_weak.upgrade() else {
                return;
            };

            let index = index as usize;

            if index >= state_clone.borrow().tab_count() {
                return;
            }

            start_close_request(
                &window,
                &state_clone,
                &pending_close_clone,
                &close_queue_clone,
                vec![index],
            );
        });
    }

    // 显示文件路径 Tooltip
    {
        let state_clone = state.clone();
        let tooltip_window_clone = tooltip_window.clone();
        let window_weak = window.as_weak();

        window.on_tooltip_show_requested(move |index, tab_x, tab_bottom_y| {
            if index < 0 {
                return;
            }

            let index = index as usize;

            let Some(path) = state_clone
                .borrow()
                .tab_paths()
                .get(index)
                .cloned()
                .filter(|path| !path.is_empty())
            else {
                return;
            };

            let Some(main_window) = window_weak.upgrade() else {
                return;
            };

            let (tooltip_width, tooltip_height) = estimate_tooltip_size(&path);

            tooltip_window_clone.set_tooltip_text(path.clone().into());

            tooltip_window_clone
                .window()
                .set_size(slint::LogicalSize::new(tooltip_width, tooltip_height));

            let main_window_handle = main_window.window();
            let main_position = main_window_handle.position();
            let scale_factor = main_window_handle.scale_factor();

            // 让 tooltip 左对齐标签左边，并在标签下方显示
            let tooltip_gap = 35.0_f32;
            let tooltip_x = main_position.x + ((tab_x + 8.0) * scale_factor).round() as i32;
            let tooltip_y =
                main_position.y + ((tab_bottom_y + tooltip_gap) * scale_factor).round() as i32;

            tooltip_window_clone
                .window()
                .set_position(slint::PhysicalPosition::new(tooltip_x, tooltip_y));

            let _ = tooltip_window_clone.show();
        });
    }

    // 隐藏文件路径 Tooltip
    {
        let tooltip_window_clone = tooltip_window.clone();

        window.on_tooltip_hide_requested(move || {
            let _ = tooltip_window_clone.hide();
        });
    }

    // 显示标签右键菜单
    {
        let window_weak = window.as_weak();

        window.on_tab_context_requested(move |index| {
            if index < 0 {
                return;
            }

            if let Some(window) = window_weak.upgrade() {
                let index = index as usize;
                let menu_x = 10.0 + index as f32 * 124.0;

                window.set_tab_menu_index(index as i32);
                window.set_tab_menu_x(menu_x.min(600.0).into());
                window.set_tab_menu_y(48.0_f32.into());
                window.set_tab_menu_visible(true);
            }
        });
    }

    // 关闭其它标签
    {
        let state_clone = state.clone();
        let pending_close_clone = pending_close.clone();
        let close_queue_clone = pending_close_queue.clone();
        let window_weak = window.as_weak();

        window.on_close_other_tabs_requested(move |index| {
            if index < 0 {
                return;
            }

            let Some(window) = window_weak.upgrade() else {
                return;
            };

            let index = index as usize;
            let count = state_clone.borrow().tab_count();

            if index >= count {
                return;
            }

            let indices = (0..count)
                .filter(|&tab_index| tab_index != index)
                .collect::<Vec<_>>();

            start_close_request(
                &window,
                &state_clone,
                &pending_close_clone,
                &close_queue_clone,
                indices,
            );
        });
    }

    // 关闭左侧标签
    {
        let state_clone = state.clone();
        let pending_close_clone = pending_close.clone();
        let close_queue_clone = pending_close_queue.clone();
        let window_weak = window.as_weak();

        window.on_close_left_tabs_requested(move |index| {
            if index <= 0 {
                return;
            }

            let Some(window) = window_weak.upgrade() else {
                return;
            };

            let indices = (0..index as usize).collect::<Vec<_>>();

            start_close_request(
                &window,
                &state_clone,
                &pending_close_clone,
                &close_queue_clone,
                indices,
            );
        });
    }

    // 关闭右侧标签
    {
        let state_clone = state.clone();
        let pending_close_clone = pending_close.clone();
        let close_queue_clone = pending_close_queue.clone();
        let window_weak = window.as_weak();

        window.on_close_right_tabs_requested(move |index| {
            if index < 0 {
                return;
            }

            let Some(window) = window_weak.upgrade() else {
                return;
            };

            let count = state_clone.borrow().tab_count();
            let index = index as usize;

            if index + 1 >= count {
                return;
            }

            let indices = ((index + 1)..count).collect::<Vec<_>>();

            start_close_request(
                &window,
                &state_clone,
                &pending_close_clone,
                &close_queue_clone,
                indices,
            );
        });
    }

    // 确认保存并关闭
    {
        let state_clone = state.clone();
        let pending_close_clone = pending_close.clone();
        let close_queue_clone = pending_close_queue.clone();
        let pending_conflict_clone = pending_conflict.clone();
        let window_weak = window.as_weak();

        window.on_confirm_save(move || {
            let Some(index) = *pending_close_clone.borrow() else {
                return;
            };

            let needs_dialog = state_clone.borrow().save_tab_needs_dialog(index);

            let result: Option<Result<(), String>> = if needs_dialog {
                let default_name = {
                    let state = state_clone.borrow();
                    state.save_default_name(index)
                };

                match file_io::pick_save_path(&default_name) {
                    Some(path) => {
                        let result = {
                            let mut state = state_clone.borrow_mut();
                            state.save_tab_as(index, path)
                        };

                        Some(result.map_err(|error| error.to_string()))
                    }
                    None => None,
                }
            } else {
                let result = {
                    let mut state = state_clone.borrow_mut();
                    state.save_tab_to_disk(index)
                };

                match result {
                    Ok(SaveOutcome::Saved) => Some(Ok(())),
                    Ok(SaveOutcome::Conflict(change)) => {
                        *pending_conflict_clone.borrow_mut() = Some(index);
                        if let Some(window) = window_weak.upgrade() {
                            let (title, message) = conflict_text_for(&state_clone, index, change);
                            window.set_confirm_visible(false);
                            window.set_conflict_title(title.into());
                            window.set_conflict_message(message.into());
                            window.set_conflict_visible(true);
                        }
                        // pending_close 保留，等冲突解决后再继续关闭
                        return;
                    }
                    Err(error) => Some(Err(error.to_string())),
                }
            };

            let Some(result) = result else {
                return;
            };

            match result {
                Ok(()) => {
                    pending_close_clone.borrow_mut().take();
                    state_clone.borrow_mut().close_tab(index);

                    if let Some(window) = window_weak.upgrade() {
                        window.set_confirm_visible(false);
                        sync_ui(&window, &state_clone);

                        request_next_close(
                            &window,
                            &state_clone,
                            &pending_close_clone,
                            &close_queue_clone,
                        );
                    }
                }
                Err(error) => {
                    eprintln!("保存失败：{error}");
                }
            }
        });
    }

    // 放弃修改并关闭
    {
        let state_clone = state.clone();
        let pending_close_clone = pending_close.clone();
        let close_queue_clone = pending_close_queue.clone();
        let window_weak = window.as_weak();

        window.on_confirm_discard(move || {
            let Some(index) = pending_close_clone.borrow_mut().take() else {
                return;
            };

            state_clone.borrow_mut().close_tab(index);

            if let Some(window) = window_weak.upgrade() {
                window.set_confirm_visible(false);
                sync_ui(&window, &state_clone);

                request_next_close(
                    &window,
                    &state_clone,
                    &pending_close_clone,
                    &close_queue_clone,
                );
            }
        });
    }

    // 取消当前标签关闭，但继续处理队列
    {
        let state_clone = state.clone();
        let pending_close_clone = pending_close.clone();
        let close_queue_clone = pending_close_queue.clone();
        let window_weak = window.as_weak();

        window.on_confirm_cancel(move || {
            pending_close_clone.borrow_mut().take();

            if let Some(window) = window_weak.upgrade() {
                window.set_confirm_visible(false);

                request_next_close(
                    &window,
                    &state_clone,
                    &pending_close_clone,
                    &close_queue_clone,
                );
            }
        });
    }

    // 冲突处理：覆盖磁盘
    {
        let state_clone = state.clone();
        let window_weak = window.as_weak();
        let pending_conflict_clone = pending_conflict.clone();
        let pending_close_clone = pending_close.clone();
        let close_queue_clone = pending_close_queue.clone();

        window.on_conflict_overwrite(move || {
            let Some(idx) = pending_conflict_clone.borrow_mut().take() else {
                return;
            };

            if let Err(error) = state_clone.borrow_mut().force_save_tab_to_disk(idx) {
                eprintln!("保存失败：{error}");
                return;
            }

            let Some(window) = window_weak.upgrade() else {
                return;
            };
            window.set_conflict_visible(false);

            // 若处于关闭流程，继续关闭
            if pending_close_clone.borrow().is_some() {
                pending_close_clone.borrow_mut().take();
                state_clone.borrow_mut().close_tab(idx);
                sync_ui(&window, &state_clone);
                request_next_close(
                    &window,
                    &state_clone,
                    &pending_close_clone,
                    &close_queue_clone,
                );
            } else {
                sync_ui(&window, &state_clone);
            }
        });
    }

    // 冲突处理：放弃我的修改
    {
        let state_clone = state.clone();
        let window_weak = window.as_weak();
        let pending_conflict_clone = pending_conflict.clone();
        let pending_close_clone = pending_close.clone();
        let close_queue_clone = pending_close_queue.clone();

        window.on_conflict_discard(move || {
            let Some(idx) = pending_conflict_clone.borrow_mut().take() else {
                return;
            };

            // 先取出状态（让 Ref 在本语句结束后立即释放），再执行操作
            let change = match state_clone.borrow().external_file_state(idx) {
                Ok(c) => c,
                Err(error) => {
                    eprintln!("获取文件状态失败：{error}");
                    return;
                }
            };

            match change {
                ExternalChange::Modified => {
                    if let Err(error) = state_clone.borrow_mut().reload_tab_from_disk(idx) {
                        eprintln!("重载失败：{error}");
                        return;
                    }
                }
                ExternalChange::Deleted => {
                    state_clone.borrow_mut().reset_to_blank(idx);
                }
                ExternalChange::Unchanged => {}
            }

            let Some(window) = window_weak.upgrade() else {
                return;
            };
            window.set_conflict_visible(false);

            if pending_close_clone.borrow().is_some() {
                pending_close_clone.borrow_mut().take();
                state_clone.borrow_mut().close_tab(idx);
                sync_ui(&window, &state_clone);
                request_next_close(
                    &window,
                    &state_clone,
                    &pending_close_clone,
                    &close_queue_clone,
                );
            } else {
                sync_ui(&window, &state_clone);
            }
        });
    }

    // 冲突处理：另存为
    {
        let state_clone = state.clone();
        let window_weak = window.as_weak();
        let pending_conflict_clone = pending_conflict.clone();
        let pending_close_clone = pending_close.clone();

        window.on_conflict_save_as(move || {
            let Some(idx) = pending_conflict_clone.borrow_mut().take() else {
                return;
            };

            // 另存为会中止关闭流程，用户需要重新发起关闭
            pending_close_clone.borrow_mut().take();

            let default_name = {
                let state = state_clone.borrow();
                state.save_default_name(idx)
            };

            let Some(path) = file_io::pick_save_path(&default_name) else {
                return;
            };

            let result = {
                let mut state = state_clone.borrow_mut();
                state.save_tab_as(idx, path)
            };

            match result {
                Ok(()) => {
                    if let Some(window) = window_weak.upgrade() {
                        window.set_conflict_visible(false);
                        sync_ui(&window, &state_clone);
                    }
                }
                Err(error) => eprintln!("另存为失败：{error}"),
            }
        });
    }

    // 冲突处理：取消
    {
        let window_weak = window.as_weak();
        let pending_conflict_clone = pending_conflict.clone();
        let pending_close_clone = pending_close.clone();

        window.on_conflict_cancel(move || {
            pending_conflict_clone.borrow_mut().take();

            // 若处于关闭流程，取消整个关闭
            let was_closing = pending_close_clone.borrow_mut().take().is_some();

            if let Some(window) = window_weak.upgrade() {
                window.set_conflict_visible(false);
                if was_closing {
                    window.set_confirm_visible(false);
                }
            }
        });
    }

    // 轻量冲突：重新加载
    {
        let state_clone = state.clone();
        let window_weak = window.as_weak();
        let pending_light_conflict_clone = pending_light_conflict.clone();

        window.on_light_conflict_reload(move || {
            let Some(idx) = pending_light_conflict_clone.borrow_mut().take() else {
                return;
            };

            if let Err(error) = state_clone.borrow_mut().reload_tab_from_disk(idx) {
                eprintln!("重新加载失败：{error}");
            }

            if let Some(window) = window_weak.upgrade() {
                window.set_light_conflict_visible(false);
                sync_ui(&window, &state_clone);
            }
        });
    }

    // 轻量冲突：保留我的修改
    {
        let window_weak = window.as_weak();
        let pending_light_conflict_clone = pending_light_conflict.clone();

        window.on_light_conflict_keep(move || {
            // 只是关掉对话框，什么都不做。冲突被推迟到保存时处理。
            pending_light_conflict_clone.borrow_mut().take();

            if let Some(window) = window_weak.upgrade() {
                window.set_light_conflict_visible(false);
            }
        });
    }

    // Ctrl+Tab
    {
        let state_clone = state.clone();
        let window_weak = window.as_weak();
        let pending_light_conflict_clone = pending_light_conflict.clone();

        window.on_next_tab_requested(move || {
            // 轻量冲突框已经开着：忽略本次切换，让用户先处理
            if let Some(w) = window_weak.upgrade() {
                if w.get_light_conflict_visible() {
                    return;
                }
            }

            let mut show_light = false;
            let idx;

            {
                let mut state = state_clone.borrow_mut();
                state.switch_to_next();
                idx = state.active_index();

                let is_dirty = state.active_tab().is_dirty;
                let modified =
                    matches!(state.external_file_state(idx), Ok(ExternalChange::Modified));

                if modified {
                    if is_dirty {
                        show_light = true;
                    } else {
                        let _ = state.reload_tab_from_disk(idx);
                    }
                }
            }

            let Some(window) = window_weak.upgrade() else {
                return;
            };

            sync_ui(&window, &state_clone);

            if show_light {
                *pending_light_conflict_clone.borrow_mut() = Some(idx);
                let (title, message) = light_conflict_text_for(&state_clone, idx);
                window.set_light_conflict_title(title.into());
                window.set_light_conflict_message(message.into());
                window.set_light_conflict_visible(true);
            }
        });
    }

    // Ctrl+F
    {
        let find_position_clone = find_position.clone();
        let window_weak = window.as_weak();

        window.on_find_requested(move || {
            *find_position_clone.borrow_mut() = 0;

            if let Some(window) = window_weak.upgrade() {
                window.set_find_visible(true);
            }
        });
    }

    // 查找关键词变化
    {
        let find_position_clone = find_position.clone();

        window.on_find_query_changed(move |_| {
            *find_position_clone.borrow_mut() = 0;
        });
    }

    // 查找下一个
    {
        let state_clone = state.clone();
        let find_position_clone = find_position.clone();
        let window_weak = window.as_weak();

        window.on_find_next_requested(move || {
            let query = window_weak
                .upgrade()
                .map(|window| window.get_find_query().to_string())
                .unwrap_or_default();

            if query.is_empty() {
                return;
            }

            let text = {
                let state = state_clone.borrow();
                state.active_tab().buffer.to_string()
            };

            if text.is_empty() {
                return;
            }

            let mut position = find_position_clone.borrow_mut();
            let start = (*position).min(text.len());

            let found = text[start..]
                .find(&query)
                .map(|offset| start + offset)
                .or_else(|| text.find(&query));

            if let Some(index) = found {
                *position = index + query.len();
                println!("找到匹配项：第 {index} 个字节位置");
            } else {
                *position = 0;
                println!("未找到：{query}");
            }
        });
    }

    // 关闭查找栏
    {
        let window_weak = window.as_weak();

        window.on_find_close_requested(move || {
            if let Some(window) = window_weak.upgrade() {
                window.set_find_visible(false);
                window.set_find_query(SharedString::default());
            }
        });
    }

    sync_ui(&window, &state);
    window.run()?;

    Ok(())
}

fn conflict_text_for(
    state: &Rc<RefCell<AppState>>,
    idx: usize,
    change: ExternalChange,
) -> (String, String) {
    let state_ref = state.borrow();
    let name = state_ref
        .tab_title(idx)
        .unwrap_or_else(|| "未命名".to_string());

    let title = match change {
        ExternalChange::Modified => "文件已被外部修改",
        ExternalChange::Deleted => "文件已被外部删除",
        ExternalChange::Unchanged => "文件状态异常",
    };

    let message = match change {
        ExternalChange::Modified => format!(
            "「{}」在磁盘上已被其他程序修改。\n你的编辑与磁盘版本可能冲突，请选择处理方式。",
            name
        ),
        ExternalChange::Deleted => format!(
            "「{}」在磁盘上已被删除。\n你的编辑仍保留在编辑器中，请选择处理方式。",
            name
        ),
        ExternalChange::Unchanged => String::new(),
    };

    (title.to_string(), message)
}

fn light_conflict_text_for(state: &Rc<RefCell<AppState>>, idx: usize) -> (String, String) {
    let state_ref = state.borrow();
    let name = state_ref
        .tab_title(idx)
        .unwrap_or_else(|| "未命名".to_string());

    let title = "文件已被外部修改".to_string();
    let message = format!(
        "「{}」在磁盘上已被其他程序修改。\n你在编辑器里还有未保存的修改，是否重新加载？",
        name
    );

    (title, message)
}

fn sync_ui(window: &MainWindow, state: &Rc<RefCell<AppState>>) {
    let state = state.borrow();

    let titles = state
        .tab_titles()
        .into_iter()
        .map(SharedString::from)
        .collect::<Vec<_>>();

    window.set_tab_titles(ModelRc::new(VecModel::from(titles)));
    window.set_tab_dirty_states(ModelRc::new(VecModel::from(state.tab_dirty_states())));
    window.set_active_index(state.active_index() as i32);
    window.set_editor_text(state.active_tab().buffer.to_string().into());
    window.set_tab_paths(ModelRc::new(VecModel::from(
        state
            .tab_paths()
            .into_iter()
            .map(SharedString::from)
            .collect::<Vec<_>>(),
    )));

    // ===== 状态栏：状态标记 =====
    let idx = state.active_index();
    let is_dirty = state.active_tab().is_dirty;

    let (badge_text, badge_color) = match state.external_file_state(idx) {
        Ok(ExternalChange::Deleted) => (
            "⚠ 已被外部删除",
            slint::Color::from_rgb_u8(0xcc, 0x33, 0x33),
        ),
        Ok(ExternalChange::Modified) => (
            "⚠ 已被外部修改",
            slint::Color::from_rgb_u8(0xcc, 0x66, 0x00),
        ),
        _ if is_dirty => ("● 未保存", slint::Color::from_rgb_u8(0xc0, 0x80, 0x00)),
        _ => ("", slint::Color::from_argb_u8(0, 0, 0, 0)),
    };

    window.set_status_badge_text(badge_text.into());
    window.set_status_badge_color(badge_color);

    // ===== 状态栏：编码 =====
    window.set_status_encoding(state.active_tab().encoding.name().into());
    window.set_status_line_ending(state.active_tab().line_ending.name().into());
    window.set_status_line_count(state.active_tab().line_count as i32);
    window.set_status_char_count(state.active_tab().char_count as i32);
}

fn request_next_close(
    window: &MainWindow,
    state: &Rc<RefCell<AppState>>,
    pending_close: &Rc<RefCell<Option<usize>>>,
    close_queue: &Rc<RefCell<Vec<usize>>>,
) {
    if pending_close.borrow().is_some() {
        return;
    }

    let Some(index) = close_queue.borrow_mut().pop() else {
        return;
    };

    let tab_count = state.borrow().tab_count();

    if index >= tab_count {
        request_next_close(window, state, pending_close, close_queue);
        return;
    }

    let needs_confirmation = state.borrow().tab_needs_close_confirmation(index);

    if needs_confirmation {
        let title = state
            .borrow()
            .tab_title(index)
            .unwrap_or_else(|| "未命名".to_string());

        *pending_close.borrow_mut() = Some(index);
        window.set_confirm_title(title.into());
        window.set_confirm_visible(true);
        return;
    }

    state.borrow_mut().close_tab(index);
    sync_ui(window, state);

    request_next_close(window, state, pending_close, close_queue);
}

fn start_close_request(
    window: &MainWindow,
    state: &Rc<RefCell<AppState>>,
    pending_close: &Rc<RefCell<Option<usize>>>,
    close_queue: &Rc<RefCell<Vec<usize>>>,
    indices: Vec<usize>,
) {
    if pending_close.borrow().is_some() {
        return;
    }

    close_queue.borrow_mut().extend(indices);
    request_next_close(window, state, pending_close, close_queue);
}

fn create_tooltip_font() -> Option<(HDC, HFONT, HGDIOBJ)> {
    let hdc = unsafe { GetDC(None) };
    if hdc.is_invalid() {
        return None;
    }

    let mut lf = LOGFONTW {
        lfHeight: -12,
        lfWidth: 0,
        lfEscapement: 0,
        lfOrientation: 0,
        lfWeight: 400,
        lfItalic: 0,
        lfUnderline: 0,
        lfStrikeOut: 0,
        lfCharSet: FONT_CHARSET(1),
        lfOutPrecision: FONT_OUTPUT_PRECISION(0),
        lfClipPrecision: FONT_CLIP_PRECISION(0),
        lfQuality: FONT_QUALITY(0),
        lfPitchAndFamily: 0,
        lfFaceName: [0; 32],
    };

    let face = "Segoe UI";
    let face_utf16: Vec<u16> = face.encode_utf16().collect();
    let len = face_utf16.len().min(31);
    let mut face_array = [0u16; 32];
    face_array[..len].copy_from_slice(&face_utf16[..len]);
    lf.lfFaceName = face_array;

    let hfont = unsafe { CreateFontIndirectW(&lf) };
    if hfont.is_invalid() {
        unsafe { ReleaseDC(None, hdc) };
        return None;
    }

    let old_font = unsafe { SelectObject(hdc, hfont) };
    if old_font.is_invalid() {
        unsafe {
            DeleteObject(hfont);
            ReleaseDC(None, hdc);
        }
        return None;
    }

    Some((hdc, hfont, old_font))
}

fn measure_tooltip_text(path: &str) -> (f32, f32) {
    const MIN_WIDTH: f32 = 180.0;
    const MAX_WIDTH: f32 = 520.0;
    const MIN_HEIGHT: f32 = 32.0;
    const X_PADDING: f32 = 16.0;
    const Y_PADDING: f32 = 10.0;

    let Some((hdc, hfont, old_font)) = create_tooltip_font() else {
        return (MIN_WIDTH, MIN_HEIGHT);
    };

    let mut rect = RECT {
        left: 0,
        top: 0,
        right: MAX_WIDTH as i32,
        bottom: 0,
    };

    let mut text = path.to_owned();
    text.push('\0');

    let mut utf16: Vec<u16> = text.encode_utf16().collect();

    unsafe {
        DrawTextExW(
            hdc,
            &mut utf16,
            &mut rect,
            DT_CALCRECT | DT_WORDBREAK | DT_NOPREFIX,
            None,
        );
    }

    let measured_width = (rect.right - rect.left) as f32;
    let measured_height = (rect.bottom - rect.top) as f32;

    unsafe {
        SelectObject(hdc, old_font);
        DeleteObject(hfont);
        ReleaseDC(None, hdc);
    }

    let width = (measured_width + X_PADDING * 2.0).clamp(MIN_WIDTH, MAX_WIDTH);
    let height = (measured_height + Y_PADDING * 2.0).max(MIN_HEIGHT);

    (width, height)
}

fn estimate_tooltip_size(path: &str) -> (f32, f32) {
    measure_tooltip_text(path)
}
